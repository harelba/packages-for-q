#-----------------------------------------------------------------------------
# Copyright (c) 2013, PyInstaller Development Team.
#
# Distributed under the terms of the GNU General Public License with exception
# for distributing bootloader.
#
# The full license is in the file COPYING.txt, distributed with this software.
#-----------------------------------------------------------------------------


attrs = [('HTML_4_STRICT_INLINE',0),
         ('HTML_4_TRANSITIONAL_INLINE',0),
          ('HTML_FORBIDDEN_END',0),
          ('HTML_OPT_END',0),
          ('HTML_BOOLEAN_ATTRS',0),
          ('HTML_CHARACTER_ENTITIES',0),
          ('HTML_NAME_ALLOWED',0),
          ('HTML_DTD',0),
          ('HTMLDOMImplementation',0),
          ('htmlImplementation',0),
          ('utf8_to_code',0),
          ('ConvertChar',0),
          ('UseHtmlCharEntities',0),
          ('TranslateHtmlCdata',0),
          ('SECURE_HTML_ELEMS',0),
        ]
