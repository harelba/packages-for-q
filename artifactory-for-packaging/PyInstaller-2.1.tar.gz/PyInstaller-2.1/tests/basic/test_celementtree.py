#-----------------------------------------------------------------------------
# Copyright (c) 2013, PyInstaller Development Team.
#
# Distributed under the terms of the GNU General Public License with exception
# for distributing bootloader.
#
# The full license is in the file COPYING.txt, distributed with this software.
#-----------------------------------------------------------------------------


# TODO Why is this string here?
"""
import xml.etree.ElementTree
from copy import copy, deepcopy
import _elementtree
import xml.etree.cElementTree
print dir(xml.etree.cElementTree)
"""


from xml.etree.cElementTree import ElementTree

print('OK')
